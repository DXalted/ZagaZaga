﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ZagaZaga.Models;

namespace ZagaZaga.Controllers
{
    public class ToolsController : Controller
    {
        private mvcEntities db = new mvcEntities();
        //
        // GET: /Tools/

        public ActionResult Index()
        {
            
            var check_sample = db.check_sample.Where(x => x.id != 0);
            ViewBag.cs = check_sample.ToList();

            var google_voice = db.google_voice.Where(x => x.id != 0);
            ViewBag.google = google_voice.ToList();

            var leads = db.leads.Where(x => x.id != 0);
            ViewBag.lead = leads.ToList();

            var letter = db.letter_writeups.Where(x => x.id != 0);
            ViewBag.let = letter.ToList();

            var mass_email = db.mass_email.Where(x => x.id != 0);
            ViewBag.me = mass_email.ToList();

            var mass_text = db.mass_text.Where(x => x.id != 0);
            ViewBag.mt = mass_text.ToList();

            
            var phone_no = db.phone_number.Where(x => x.id != 0);
            ViewBag.phone = phone_no.ToList();

            var rdp = db.rdp.Where(x => x.id != 0);
            ViewBag.rdp = rdp.ToList();

            var send_check = db.send_check.Where(x => x.id != 0);
            ViewBag.sc = send_check.ToList();

            return View();
        }
        //public ActionResult bank_account()
        //{

        //    var bank_accounts = db.bank_account.Where(x => x.id != 000);
        //    ViewBag.bank = bank_accounts.ToList();

        //    return View();
        //}



    }
}
