namespace ZagaZaga.Models.GoUrl
{
    public class LocalisationModel
    {
        public string Name { get; set; }
        public string Button { get; set; }
        public string MsgNotReceived { get; set; }
        public string MsgReceived { get; set; }
        public string MsgReceived2 { get; set; }
        public string Payment { get; set; }
        public string PayIn { get; set; }
    }
}